function [ S ] = rootrow( x,eps )
%ROOTROW Summary of this function goes here
%   Detailed explanation goes here
n = 1;
a = 1;
S = a;
x=x-1;
while(abs(a./S) > eps)
    
    R = ((((1./2)-n+1)*x)./(n));
    a = a .* R;
   
    A(n) = a;
    S = S + a;
    fprintf('S-%d n-%d \n',S,n);
      n = n+1;
end
fprintf('%d',S);
bar(A);


end

