function [ S ] = lnrow( x, eps )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
x=x-1;
n = 1;
a = x;
S = a;
while(abs(a)./abs(S) >= eps)
    n = n+1;
    R = ((-1).*x.*(n))./(n+1);
    a = a .* R;
  % a=((-1).^(n+1).*(x).^n)./(n);
   % A(n) = a;
    S = S + a;
    fprintf('S-%d n-%d \n',S,n);
      
end
fprintf('%d',S);

%bar(A);

end

