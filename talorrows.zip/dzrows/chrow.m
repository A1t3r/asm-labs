function [ S ] = chrow( x, eps )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
n = 0;
a = 1;
S = a;
while(abs(a)/abs(S) >= eps)
    
    n = n+1;
    R = (x^2)/((2*n)*(2*n-1));
    a = a * R;
   % A(n) = a;% ��� bar
    S = S + a;
end
%bar(A);

end

