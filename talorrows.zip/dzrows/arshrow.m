function [ S ] = arshrow( x, eps )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
n = 0;
a = x;
S = a;
while(abs(a)/abs(S) >= eps)
    
    n = n+1;
    R = ((-1)*(2*n+1)*(2*n+2)*x*x)/(4*(n+1)^2*(2*n+2));
    a = a * R;
   % A(n) = a;% ��� bar
    S = S + a;
end
%bar(A);

end
