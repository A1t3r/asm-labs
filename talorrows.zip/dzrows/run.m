x=-10:0.1:10;
 for i=1:1:length(x)
     y(i)=exprow(x(i),0.01);
     x=-10:0.1:10;
     y=exprow(x,0.5);
plot(x,exprow(x,0.5),'r',x,exp(x),'g')
 end