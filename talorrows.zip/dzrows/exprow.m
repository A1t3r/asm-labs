function [ S ] = exprow( x,eps )
%EXPROW Summary of this function goes here
%   Detailed explanation goes here
n = 1;
a = 1;
S = a;
while(abs(a./S) > eps)
    
    R = x./(n);
    a = a .* R;
    %A(n) = a;
    S = S + a;
    fprintf('S-%d n-%d \n',S,n);
      n = n+1;
end
fprintf('%d',S);
%bar(A);

end

